package com.example.trainia

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
