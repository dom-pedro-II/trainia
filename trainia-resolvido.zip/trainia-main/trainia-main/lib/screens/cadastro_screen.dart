import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import '../models/user_model.dart';
import 'login_screen.dart';

class CadastroScreen extends StatefulWidget {
  const CadastroScreen({super.key});

  @override
  State<CadastroScreen> createState() => _CadastroScreenState();
}

class _CadastroScreenState extends State<CadastroScreen> {
  final _formKey = GlobalKey<FormState>();
  final _controllers = {
    'email': TextEditingController(),
    'nome': TextEditingController(),
    'senha': TextEditingController(),
    'idade': TextEditingController(),
    'altura': TextEditingController(),
    'peso': TextEditingController(),
  };

  String? _erro;

  Future<void> _cadastrar() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _erro = null);

    final email = _controllers['email']!.text;

    final existe = await AuthService.usuarioJaCadastrado(username: email);
    if (existe) {
      setState(() => _erro = 'Usuário já cadastrado.');
      return;
    }

    final user = UserModel(
      nome: _controllers['nome']!.text,
      email: email,
      senha: _controllers['senha']!.text,
      idade: int.parse(_controllers['idade']!.text),
      altura: double.parse(_controllers['altura']!.text),
      peso: double.parse(_controllers['peso']!.text),
    );

    final sucesso = await AuthService.cadastrar(user, sportsModality: '', username: email, activityLevel: '');
    if (sucesso) {
      setState(() => _erro = null);
    } else {
      setState(() => _erro = 'Erro ao cadastrar usuário.');
    }
    // Verifica se o cadastro foi bem-sucedido

    if (sucesso) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const LoginScreen()),
      );
    } else {
      setState(() => _erro = 'Erro ao cadastrar usuário.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Cadastro')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              for (var entry in _controllers.entries)
                TextFormField(
                  controller: entry.value,
                  decoration: InputDecoration(labelText: entry.key),
                  obscureText: entry.key == 'senha',
                  validator: (v) => v!.isEmpty ? 'Preencha o campo' : null,
                ),
              const SizedBox(height: 16),
              if (_erro != null)
                Text(_erro!, style: const TextStyle(color: Colors.red)),
              ElevatedButton(
                onPressed: _cadastrar,
                child: const Text('Cadastrar'),
              )
            ],
          ),
        ),
      ),
    );
  }
}
