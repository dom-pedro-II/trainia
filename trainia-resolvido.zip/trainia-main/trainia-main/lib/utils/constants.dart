class Constants {
  static const String appName = "Trainia";
}
