
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'dart:convert';

class FileHelper {
  static Future<String> get _localPath async {
    final directory = await getApplicationDocumentsDirectory();
    return directory.path;
  }

  static Future<File> _localFile(String filename) async {
    final path = await _localPath;
    return File('$path/$filename');
  }

  static Future<dynamic> readJson(String filename) async {
    try {
      final file = await _localFile(filename);
      final contents = await file.readAsString();
      return json.decode(contents);
    } catch (e) {
      print("Erro ao ler o arquivo $filename: $e");
      return null;
    }
  }

  static Future<void> writeJson(String filename, dynamic data) async {
    final file = await _localFile(filename);
    final contents = json.encode(data);
    await file.writeAsString(contents);
  }
}

class HistoricoService {
  static const _file = 'historico_treinos.json';

  static Future<List<Map<String, dynamic>>> listar() async {
    final data = await FileHelper.readJson(_file);
    if (data == null) return [];
    return List<Map<String, dynamic>>.from(data);
  }

  static Future<void> salvar(Map<String, dynamic> treino) async {
    final lista = await listar();
    lista.insert(0, treino);
    await FileHelper.writeJson(_file, lista);
  }
}
